﻿using Food;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DB_OrderInfo
{
    public interface IRepository
    {
        //AddIngredientToPizzaAsync(int pizzaID, int[] ingridients);
       //IEnumerable<Drink>> ShowDrinks();
       //IEnumerable<Extra>> ShowExtra();
       //IEnumerable<Ingredient>> ShowIngredients();
       //IEnumerable<OrderFood>> ShowOrderFood();
       //IEnumerable<Pasta>> ShowPastasAsync();
       //IEnumerable<PizzaIngredient>> ShowPizzaAndIngredients();
       //IEnumerable<Pizza>> ShowPizzasAsync();
       //IEnumerable<Sallad>> ShowSalladsAsync();
    }
}