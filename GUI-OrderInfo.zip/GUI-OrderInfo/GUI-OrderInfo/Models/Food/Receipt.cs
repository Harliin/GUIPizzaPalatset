﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Food
{
    public class Receipt
    {
        public string OrderInfo { get; set; }
        public int TotalPrice { get; set; }
    }
}
