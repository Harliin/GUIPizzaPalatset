﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Food
{
    public class Pasta
    {
        public int ID { get; set; }

        public int OrderID { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string Ingredient1 { get; set; }
        public string Ingredient2 { get; set; }
        public string Ingredient3 { get; set; }
        public string Ingredient4 { get; set; }
        public string Ingredient5 { get; set; }
    }
}
