﻿using DB_OrderInfo.Food;
using GUI_OrderInfo.Views;
using System.Threading;

namespace GUI_OrderInfo.ViewModels
{
    public class MainWindowViewModels
    {
        public MainWindowViewModels()
        {
            OrderInfoRepository repository = new OrderInfoRepository();

            // Printar ut pågående ordrar
            foreach (Order ongoingOrder in repository.OngoingOrder())
            {
                MainWindowView ongoing = new MainWindowView();
                ongoing.txbOngoing.Text = ongoingOrder.ToString();
            }

            // Printar ut färdiga ordrar 
            foreach (Order completeOrder in repository.CompleteOrder())
            {
                MainWindowView complete = new MainWindowView();
                complete.txbOngoing.Text = completeOrder.ToString();
            }

            Thread.Sleep(3000); // uppdateras varje 3 sekunder
        }
    }
}
